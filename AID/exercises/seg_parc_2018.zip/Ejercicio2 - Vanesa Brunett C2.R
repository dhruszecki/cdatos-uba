rm(list=ls())
library(tidyverse)
library(haven)
library(ADGofTest)
library(nortest)
library(MASS) 
library(RVAideMemoire)
library(car)
library(reshape2)
library(moments)
library(foreign)
library(pgirmess)
library(readxl)


# cargar base, asignar factors y verificar numericos

setwd("C:/Users/plope/Documents/1 Pablo/Vane/maestria/")
base <- read_excel("ratas.xls") %>% as.data.frame(.)

# chequear na.omit

sum(is.na(base)) #verifico que no haya datos faltantes

#Como me dio 0, no existen en la base datos faltantes

sapply(base, class) # con este comando me fijo que tipo de dato es cada campos

base$tratamiento <- as.factor(base$tratamiento)

factor <- base$tratamiento
valor <- base$globulos
  
# medias y desvios agrupados por el factor
  
meanAll<-aggregate(valor~factor, base, function(x) c(mean=mean(x)))
meanAll
sdAll<-aggregate(valor~factor, base, function(x) c(sd=sd(x)))
sdAll
  
  
#boxplots
ggplot(base,aes(factor,valor, fill=factor, color=factor)) + 
    geom_boxplot(alpha=0.5)
  
#test ANOVA  
aov.res <- aov(valor ~ factor)
summary(aov.res)

#normalidad de los  residuos
shapiro.test(aov.res$residuals)
nortest::ad.test(aov.res$residuals)
agostino.test(aov.res$residuals)

#analizo graficamente
qqPlot(aov.res$residuals,ylab = "residuos",col = "coral",pch = 19,main = "Normal Q-Q Plot",col.lines = "cadetblue")

#homocedasticidad
leveneTest(valor ~ factor, data = base)




  
