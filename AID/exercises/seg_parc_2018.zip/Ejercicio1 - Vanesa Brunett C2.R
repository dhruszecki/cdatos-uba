#Cargo librerias necesarias

library(tidyverse)
library(haven)
library(readxl)
library(ADGofTest)
library(nortest)
library(MASS)
library(RVAideMemoire)
library(car)
library(reshape2)
library(moments)
library(pgirmess)
library(profileR)
library(Hotelling)
library(mvnormtest)
library(corpcor)
library(rpanel)
library(biotools)
library(klaR)
library(tidyr)
library(dplyr)
library(rrcov)
library(caret)
library(scatterplot3d) 
library(MVN)
library(corrplot)


# cargar base, asignar factors y verificar numericos

setwd("C:/Users/plope/Documents/1 Pablo/Vane/maestria/")
base <- read_excel("anticuerpos.xls") %>% as.data.frame(.)

# chequear na.omit

sum(is.na(base)) 

#verifico que no haya datos faltantes
#Como me dio 0, no existen en la base datos faltantes

# con este comando me fijo que tipo de dato es cada campos
sapply(base, class) 


matriz <- as.matrix(base[,3:6]) 
base$Grupo <- as.factor(base$Grupo)
factor <- base$Grupo

#divido los grupos
cc = split(base, base$Grupo)

grupo1=cc[[1]]
grupo2=cc[[2]]
grupo1=grupo1[,3:6]
grupo2=grupo2[,3:6]
class(grupo1)

a = hotelling.test(grupo1,grupo2)
a

#TESTEO NORMALIDAD MULTIVARIADA

  
test_shapiro <- mshapiro.test(t(as.matrix(matriz))) 
test_shapiro

#TESTEO HOMOCEDASTICIDAD

boxM(base[,3:6], factor)

#funcion discriinate lineal
modelo_lda <- lda(formula = factor ~Colesterol + Albúmina + Aurico + Calcio, data = base)
modelo_lda

#clasificacion ingenua
predicciones <- predict(object = modelo_lda, newdata = base[,3:6])
table(base$Grupo, predicciones$class, dnn = c("Clase real", "Clase predicha"))

training_error <- mean(base$Grupo != predicciones$class) * 100
training_error


#validacion cruzada
muestra_test <- sample(1:nrow(base),nrow(base)*0.3) #se define la muestra, que es el 30%
testing <- base[muestra_test,] #testing

anticuerpos_lda_train <- lda(training[,c(3,4,5,6)], training$Grupo)
training <- base[-muestra_test,]
anticuerpos_predict <- predict(anticuerpos_lda_train, testing[,c(3,4,5,6)]) %>% as.data.frame()
predicted <- cbind(testing,predicted_class = anticuerpos_predict$class)
train_test <- table(predicted$Grupo, predicted$predicted_class)
train_test
train_test/nrow(predicted)


#pruebo para 1 caso
modelo_train = lda(training[,(3:6)], training$Grupo)

a = c(240,39,101,49)
pred_test = predict(modelo_train, a)$class
pred_test


#observaciones atipicas

# cargar base, asignar factors y verificar numericos

setwd("C:/Users/plope/Documents/1 Pablo/Vane/maestria/")
base_atipica <- read_excel("anticuerpos2.xls") %>% as.data.frame(.)

#vuelvo a aplicar analisis discriminate lineal a la nueva base

modelo_lda <- lda(formula = Grupo ~Colesterol + Albúmina + Aurico + Calcio, data = base_atipica)
modelo_lda


#clasificacion ingenua
predicciones <- predict(object = modelo_lda, newdata = base_atipica[,3:6])
table(base_atipica$Grupo, predicciones$class, dnn = c("Clase real", "Clase predicha"))

training_error <- mean(base_atipica$Grupo != predicciones$class) * 100
training_error

#validacion cruzada
muestra_test <- sample(1:nrow(base),nrow(base_atipica)*0.3) #se define la muestra, que es el 30%
training <- base_atipica[-muestra_test,]

anticuerpos_lda_train <- lda(training[,c(3,4,5,6)], training$Grupo)
anticuerpos_predict <- predict(anticuerpos_lda_train, testing[,c(3,4,5,6)]) %>% as.data.frame()
predicted <- cbind(testing,predicted_class = anticuerpos_predict$class)
train_test <- table(predicted$Grupo, predicted$predicted_class)
train_test
train_test/nrow(predicted)

#Aplico un metodo de discriminacion robusta a esta base con datos atipicos

#METODO SDE
rob.sde=QdaCov(base_atipica$Grupo~., data = base_atipica, method="sde")
predict(rob.sde)@classification
table(predict(rob.sde)@classification,base_atipica$Grupo)
mean(predict(rob.sde)@classification==base_atipica$Grupo) # tasa de buena clasif ingenua del discr robusto



