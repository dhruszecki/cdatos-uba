  library(ggdendro)#dibuja dendogramas
  library(factoextra)#dendograma de color
  library(Hotelling)#test de hotelling
  library(haven)#para importar datos de otros programas
  library(ADGofTest)#test de anderson darling
  library(nortest)#test de normalidad
  library(MASS)#test de box&cox
  library(RVAideMemoire)
  library(car)#anova
  library(reshape2)
  library(moments)#test dagostino
  library(ggplot2)#graficos lindos
  library( pgirmess)#comparaciones a posteriori
  library(biotools)#test M de Box
  library(vegan)
  library(readxl)#leer archivos excel
  library(mlbench)
  library(readr)


# cargar base, asignar factors y verificar numericos

setwd("C:/Users/plope/Documents/1 Pablo/Vane/maestria/")
base <- read_excel("lectura.xlsx") %>% as.data.frame(.)

sapply(base, class)

base$grupo <- as.factor(base$grupo)
factor <- base$grupo
  valor <- base$acierto

#grafico el boxplot por grupos de la cantidad de aciertos
  
ggplot(base,aes(factor,valor, fill=factor, color=factor)) + 
    geom_boxplot(alpha=0.5)
  
#grafico el boxplot que compara percepcion del alumno y realidad

base$dificult_lect <- as.factor(base$dificult_lect)

ggplot(base,aes(base$dificult_lect,base$acierto, fill="red", color="coral")) + 
  geom_boxplot(alpha=0.5)

#observo las medias numericamente
meanAll<-aggregate(base$acierto~base$dificult_lect, base, function(x) c(mean=mean(x)))
meanAll

#analizo boxplots comparando en forma univariada vs la capacidad de comprension lectora

# analizo el % de materias aprobadas
ggplot(base,aes(factor, base$porcmataprob, fill=factor, color=factor)) + 
  geom_boxplot(alpha=0.5)

#analizo las medias por gestions
meanAll<-aggregate(base$acierto~base$gestion, base, function(x) c(mean=mean(x)))
meanAll

#analizo las medias por secundario
meanAll<-aggregate(base$acierto~base$tipo.secund, base, function(x) c(mean=mean(x)))
meanAll

